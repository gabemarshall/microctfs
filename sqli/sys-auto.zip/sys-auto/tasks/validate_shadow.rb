system("/usr/bin/md5sum /etc/shadow")
